# Lisähuomiot (käyttäjän antama)

Keskity Naantalista lähteviin risteilymatkoihin aluksilla Finnsirius ja Finncanopus