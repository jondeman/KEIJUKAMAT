# Lisähuomiot (käyttäjän antama)

Huomioi ryhmäliikunta -mahdollisuudet sekä myös nuoret (15-17-vuotiaat) ja eläkeläis -kohderyhmä