sdk_http_response=HttpResponse(
  headers=<dict len=11>
) candidates=[Candidate(
  content=Content(),
  finish_reason=<FinishReason.STOP: 'STOP'>,
  index=0
)] create_time=None model_version='gemini-3-pro-preview' prompt_feedback=None response_id='AXlvaZLwLKSJ7M8Pm6atkQs' usage_metadata=GenerateContentResponseUsageMetadata(
  prompt_token_count=1988,
  prompt_tokens_details=[
    ModalityTokenCount(
      modality=<MediaModality.TEXT: 'TEXT'>,
      token_count=1988
    ),
  ],
  thoughts_token_count=4449,
  total_token_count=6437
) automatic_function_calling_history=[] parsed=None