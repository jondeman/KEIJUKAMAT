# Lisähuomiot (käyttäjän antama)

Keskity hoitopolusta digitaalisen kommunikointiin etenkin ikääntyvässä kohderyhmässä (yli 55-vuotiaat)