# Lisähuomiot (käyttäjän antama)

Huomioi  optikkopalveluiden lisäksi myös leikkauspalvelut (linssileikkaus ja silmäluomileikkaus)