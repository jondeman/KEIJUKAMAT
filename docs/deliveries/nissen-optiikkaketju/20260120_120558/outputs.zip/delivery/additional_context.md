# Lisähuomiot (käyttäjän antama)

huomioi kolme eri kuluttajakohderyhmää 1) nuoret 15-24 2) 25-45 3) 46-64