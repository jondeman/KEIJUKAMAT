# Concept Package: Paulig

*Generated: 2026-01-27 10:59 UTC*
*Run ID: 20260127_104706*

---

## Contents

### Research
- [Strategic Dossier](research/strategic_dossier.md)

### Concepts
- [Concept 1: Maun Mestari](concepts/concept_01.md)
- [Concept 2: Ruokaromanssi](concepts/concept_02.md)
- [Concept 3: Maailman Makuun](concepts/concept_03.md)

### Visual One-Pagers
- (Kuvat jäivät pois: Gemini Image ei vastannut)

### One-Pager PDFs
- (PDF-toimitukset puuttuvat: generointi epäonnistui tai kuvat puuttuivat)

### One-Pager Prompts
- [onepager_prompt_concept_01_20260127_105919.md](onepagers/prompts/onepager_prompt_concept_01_20260127_105919.md)
- [onepager_prompt_concept_02_20260127_105919.md](onepagers/prompts/onepager_prompt_concept_02_20260127_105919.md)
- [onepager_prompt_concept_03_20260127_105919.md](onepagers/prompts/onepager_prompt_concept_03_20260127_105919.md)

### Delivery
- [Pitch Email Draft](delivery/pitch_email.md)
