# Lisähuomiot (käyttäjän antama)

Rakenna konsepti Valokuitunen persoonan kautta. Eli kuluttajia opastava henkilö Mr tai Ms Valokuitunen