# Lisähuomiot (käyttäjän antama)

Huomioi kolme eri kuluttajakohderyhmää 1) 15-24 -vuotiaat 2) 25-45 -vuotiaat 3) 46-64 -vuotiaat