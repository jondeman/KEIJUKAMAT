# Lisähuomiot (käyttäjän antama)

Painotuksena tuotekehitys ja jalostetun erikoislaatuisen ruostumattoman teräksen uudet innovatiiviset käyttötavat