# Lisähuomiot (käyttäjän antama)

B2B-painotus: pyrkimyksemme on vaikuttaa raaka-ainepäätöksiä Euroopan teollisuudessa tekeviin päättäjiin. Mutta konseptien tulee olla viihdyttäviä kaikille!