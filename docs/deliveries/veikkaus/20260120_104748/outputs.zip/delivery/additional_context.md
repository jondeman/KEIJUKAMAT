# Lisähuomiot (käyttäjän antama)

Vastuullinen suomalainen toimija joka on ollut rakentamassa suomalaista kulttuuria ja urheilua