# One-Pager Prompt — concept_02

## SILMIEN TAKANA

```
High-quality horizontal infographic one-pager in 16:9 landscape ratio. Final output should be 3840x2160 (4K UHD) for screen presentation.

## OVERALL VISUAL STYLE
Bold, energetic, contemporary Finnish style. Strong graphics, dynamic composition, social-media-native visual language. Urban, fresh, attention-grabbing. High contrast, unexpected color pops, modern edge.
The design must feel premium, professional, and pitch-ready – like it could be presented at a top creative agency.
Mood: bold, energetic, contemporary

## LOGO PLACEMENT (CRITICAL)
- TOP LEFT CORNER: Small, elegant Warner Bros. International Television Production Finland logo (use light/white version if dark background)
- TOP RIGHT CORNER: Small, elegant Synsam Optikko company logo
- Both logos are placed discretely at the very top edge (approximately 3-4% of image height), maintaining balance and symmetry
- Logos must NOT dominate – they are subtle professional identifiers only
Jos et löydä tarkkaa logoa tai brändivärejä, käytä Synsam Optikkon virallista logoa sekä logoon ja brändi-ilmeeseen sopivia värisävyjä.

## HEADER SECTION (top 18%)
Below the logos:
- LARGE BOLD TITLE: "SILMIEN TAKANA"
- Subtitle: "TikTok-sarja, jossa Synsamin optikot ja tyyliasiantuntijat paljastavat sen, mitä he *oikeasti* aj..."
Typography: Bold, modern Finnish advertising style, highly legible, strong visual impact

## TIIVISTYS (TOP)
Immediately after the title, include a compact 3-line summary block:
- **MITÄ?** TikTok-sarja, jossa Synsamin optikot ja tyyliasiantuntijat paljastavat sen, mitä he *oikeasti* ajattelevat asiakaskohtaamisissa – mutta käänteisesti. Sen sij...
- **MITEN?** **Pääformaatti:** - 60–90 sekunnin TikTok-jaksoja, joissa yhdistetään:   - Aito myymäläkuvaus (asiakas antanut suostumuksen)   - Voice-over tai tekstioverlay...
- **MIKSI?** Tekee Synsam Optikkosta puheenaiheen ja muuttaa kiinnostuksen toiminnaksi.
These lines must be punchy and attention-grabbing, capturing the core idea fast.



## MAIN VISUAL SECTION (middle 52%)
Section title: "KONSEPTIN YDIN"

TikTok-sarja, jossa Synsamin optikot ja tyyliasiantuntijat paljastavat sen, mitä he *oikeasti* ajattelevat asiakaskohtaamisissa – mutta käänteisesti. Sen sijaan, että näytettäisiin myyntipuhe, näytetään **sisäinen monologi**: epävarmuudet, oivallukset, ilon hetket ja ammattiylpeys. Jokainen 60–90 sekunnin jakso seuraa yhtä aitoa asiakaskohtaamista, jossa ruudulle ilmestyy optiikan tekstinä hänen todelliset ajatuksensa: "Hän sanoo haluavansa 'jotain neutraalia', mutta näen että hän vilkuilee noit...

This section should visually communicate the core concept in a rich, infographic style.
Use stylized illustrations, photo compositions, and graphic elements that match the brand aesthetic.
Include key characters, settings, or scenarios that bring the concept to life.
This must feel like a fully art-directed pitch visual, not a minimal poster.

## PROCESS/FORMAT SECTION (20%)
Title: "NÄIN SE TOIMII"

**Pääformaatti:**
- 60–90 sekunnin TikTok-jaksoja, joissa yhdistetään:
  - Aito myymäläkuvaus (asiakas antanut suostumuksen)
  - Voice-over tai tekstioverlay optikon "ajatuksista"
  - Lopussa reveal: asiakkaan reaktio valittuihin laseihin
- Editointi: nopea, platform-natiivi, ASMR-henkinen äänimaailma (kehysten napsahdukset, peilin avaaminen)

**Julkaisurytmi ja kaari:**
- Lanseeraus: 3 jaksoa samana päivänä (algoritmibuusti)
- Jatkuva: 2 jaksoa/viikko, 8 viikon kausi
- Temaattiset viikot: "Ensimmäiset lasit" / "Lasit työhaastatteluun" / "Kun tyyli on jumissa"

**Laajennukset:**
- **IG Reels:** Sama sisältö, kevyesti muokatut tekstit
- **YouTube Shorts:** Kootut "Best of" -koosteet kuukausittain
- **UGC-haaste:** #SilmienTakana – asiakkaat kuvaavat oman "mitä oikeasti halusin vs. mitä sanoin" -videon
- **Myymälä:** QR-koodi kassalla: "Haluatko nähdä mitä optikkosi ajatteli? Skannaa ja katso oma jaksosi" (opt-in erikoiskokemus valikoiduille)
- **PR:** "Suomen ensimmäinen optikko, joka näyttää ajatuksensa" – lifestyle-media ja aamutv-potentiaali

---

Present as a clear visual flowchart or step-by-step (3-5 stages) with:
- Each stage in a colored box connected by arrows or visual flow
- Icon or small visual + short descriptive text per stage
- Color-coded using brand palette

## BOTTOM SECTION (10%)
Title: "STRATEGINEN MONIALUSTAINEN ILMIÖ"

Three-column layout showing distribution:
- Primary channel icon + name
- Secondary channels
- Impact/reach indicators

## FOOTER
"Konsepti joka tekee Synsam Optikkosta puheenaiheen ja tavoittaa uusia yleisöjä."
A compelling summary of why this concept is perfect for this brand.

## COLOR PALETTE
- Primary brand color: #000000
- Secondary color: #FFFFFF
- Accent color: #FFD400
- Background: Dynamic gradient or bold brand color with graphic elements
- Text: High contrast for excellent readability

## TECHNICAL REQUIREMENTS
- 16:9 landscape layout (target 3840x2160)
- Wide, cinematic composition with clear horizontal flow
- All Finnish text must be clearly readable and well-spaced
- Professional marketing document quality matching top creative agencies
- Avoid generic stock photo aesthetics
- No AI-looking artifacts or distortions in faces
- Clean, sharp typography throughout
- Premium infographic design language
- The one-pager should immediately communicate value and create desire to learn more

```
