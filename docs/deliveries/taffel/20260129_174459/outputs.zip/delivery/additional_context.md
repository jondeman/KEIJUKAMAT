# Lisähuomiot (käyttäjän antama)

Painota Sanoma median medioita, etenkin tv ja ruutu vod palvelua mediaratkaisuissa