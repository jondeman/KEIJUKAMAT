# Concept Package: Lidl

*Generated: 2026-01-19 18:55 UTC*
*Run ID: 20260119_183903*

---

## Contents

### Research
- [Strategic Dossier](research/strategic_dossier.md)

### Concepts
- [Concept 1: Suomen Halvin Keittiö](concepts/concept_01.md)
- [Concept 2: Lidl vs. Bonus](concepts/concept_02.md)
- [Concept 3: Lidl Leftovers Live](concepts/concept_03.md)

### Visual One-Pagers
- [Concept 1 One-Pager](onepagers/concept_01.png)
- [Concept 2 One-Pager](onepagers/concept_02.png)
- [Concept 3 One-Pager](onepagers/concept_03.png)

### Delivery
- [Pitch Email Draft](delivery/pitch_email.md)
