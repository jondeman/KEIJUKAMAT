# Lisähuomiot (käyttäjän antama)

Keskity kuluttajille kohdistettaviin vakuutuspalveluihin. Markkina-alueena isot kaupungit