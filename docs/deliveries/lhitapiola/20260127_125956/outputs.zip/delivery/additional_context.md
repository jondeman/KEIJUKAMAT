# Lisähuomiot (käyttäjän antama)

Keskitys LähiTapiolan vakuutuspalveluihin. Huomioi pääkohderyhmänä isoissa kaupungeissa asuvat taloudet