# Lisähuomiot (käyttäjän antama)

Keskity LähiTapiolan vakuutusten kuluttajatuotteisiin. Markkina-alueena isojen kaupunkien kotitaloudet