# Lisähuomiot (käyttäjän antama)

Keskitys LähiTapiolan vakuutusmarkkinointiin kuluttajille. Pääkohderyhmänä isoissa kaupungeissa asuvat taloudet