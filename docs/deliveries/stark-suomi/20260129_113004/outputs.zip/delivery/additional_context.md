# Lisähuomiot (käyttäjän antama)

Luo konseptit joilla peruskorjataan asuntoja, kesämökkiä, terasseja