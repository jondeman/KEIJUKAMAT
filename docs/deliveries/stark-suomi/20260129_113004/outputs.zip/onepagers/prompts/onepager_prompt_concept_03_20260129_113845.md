# One-Pager Prompt — concept_03

## Rakentajan Olympialaiset

```
High-quality horizontal infographic one-pager in 16:9 landscape ratio. Final output should be 3840x2160 (4K UHD) for screen presentation.

## OVERALL VISUAL STYLE
Visionary, cinematic, premium Finnish aesthetic. Award-worthy design quality, sophisticated layering, dramatic lighting. Editorial boldness, statement-making, the kind of design that wins at Cannes Lions.
The design must feel premium, professional, and pitch-ready – like it could be presented at a top creative agency.
Mood: visionary, impactful, premium

## LOGO PLACEMENT (CRITICAL)
- TOP LEFT CORNER: Small, elegant Warner Bros. International Television Production Finland logo (use light/white version if dark background)
- TOP RIGHT CORNER: Small, elegant Stark Suomi company logo
- Both logos are placed discretely at the very top edge (approximately 3-4% of image height), maintaining balance and symmetry
- Logos must NOT dominate – they are subtle professional identifiers only
Jos et löydä tarkkaa logoa tai brändivärejä, käytä Stark Suomin virallista logoa sekä logoon ja brändi-ilmeeseen sopivia värisävyjä.

## HEADER SECTION (top 18%)
Below the logos:
- LARGE BOLD TITLE: "Rakentajan Olympialaiset"
- Subtitle: "Suomen ensimmäinen ammattitaitokilpailun viihdeformaatti, jossa rakennusalan ammattilaiset – kirv..."
Typography: Bold, modern Finnish advertising style, highly legible, strong visual impact

## TIIVISTYS (TOP)
Immediately after the title, include a compact 3-line summary block:
- **MITÄ?** Suomen ensimmäinen ammattitaitokilpailun viihdeformaatti, jossa rakennusalan ammattilaiset – kirvesmiehet, laatoittajat, rappauksen tekijät – kilpailevat toi...
- **MITEN?** **Pääformaatti:** - 8-osainen TV-sarja (45 min/jakso) + 90 minuutin live-finaali - Jokainen jakso = yksi "laji" (terassi, kylpyhuone, energiaremontti, kesämö...
- **MIKSI?** Tekee Stark Suomista puheenaiheen ja muuttaa kiinnostuksen toiminnaksi.
These lines must be punchy and attention-grabbing, capturing the core idea fast.


## LISÄHUOMIOT (kevyt painotus)
Luo konseptit joilla peruskorjataan asuntoja, kesämökkiä, terasseja
Käytä tätä ohjaavana sävynä, älä syrjäytä konseptin ydintä.
TÄRKEÄÄ: ÄLÄ kirjoita näitä lisähuomioita sellaisenaan onepageriin.
Tiivistä teksti tai käytä pienempiä fontteja, jotta lauseet eivät katkea '...'.


## TOTAL-TV FOCUS (MANDATORY)
- All concepts must be serialized and suitable for linear TV channels and broadcaster VOD platforms.
- No digital/social-first concepts; social is only an extension.


## MAIN VISUAL SECTION (middle 52%)
Section title: "KONSEPTIN YDIN"

Suomen ensimmäinen ammattitaitokilpailun viihdeformaatti, jossa rakennusalan ammattilaiset – kirvesmiehet, laatoittajat, rappauksen tekijät – kilpailevat toisiaan vastaan käytännön lajeissa: nopeimmassa terassinrakennuksessa, tarkimmassa laatoituksessa, kestävimmässä peruskorjausratkaisussa. Jokainen jakso on oma "lajinsa", jossa kaksi joukkuetta ratkaisee saman remonttihaasteen – kesämökin saunaremontti, kerrostaloasunnon kylpyhuone, vanhemman talon energiaremontti. Tuomaristo koostuu alan konk...

This section should visually communicate the core concept in a rich, infographic style.
Use stylized illustrations, photo compositions, and graphic elements that match the brand aesthetic.
Include key characters, settings, or scenarios that bring the concept to life.
This must feel like a fully art-directed pitch visual, not a minimal poster.

## PROCESS/FORMAT SECTION (20%)
Title: "NÄIN SE TOIMII"

**Pääformaatti:**
- 8-osainen TV-sarja (45 min/jakso) + 90 minuutin live-finaali
- Jokainen jakso = yksi "laji" (terassi, kylpyhuone, energiaremontti, kesämökki jne.)
- Kaksi joukkuetta (2–3 henkeä/joukkue) kilpailevat samasta tehtävästä rinnakkain

**Julkaisurytmi:**
- Viikoittainen prime time -lähetys + VOD heti perään
- Aluekarsinnat kuvataan kesällä, pääsarja syksyllä, live-finaali joulukuussa

**Laajennukset:**
- **TikTok/Reels:** 30–60 sek. klipit – dramaattiset hetket, "miten tämä tehdään oikein" -osuudet, kilpailijaesittelyt
- **YouTube:** Täydet jaksot + "Rakentajan Mestariluokka" -lisäsisältö (tuomarit opettavat tekniikoita)
- **Live-finaali:** Studiotapahtuma yleisölle (mahdollisesti Stark Nonstop -myymälän pihalla/hallissa)
- **OOH:** Aluekarsintojen mainokset paikallisesti ("Oulun paras rakentaja – onko se sinä?")
- **PR:** Hakukampanja ammattilehdissä ja -somekanavissa, "Ilmoittaudu Rakentajan Olympialaisiin"

---

Present as a clear visual flowchart or step-by-step (3-5 stages) with:
- Each stage in a colored box connected by arrows or visual flow
- Icon or small visual + short descriptive text per stage
- Color-coded using brand palette

## BOTTOM SECTION (10%)
Title: "STRATEGINEN MONIALUSTAINEN ILMIÖ"

Three-column layout showing distribution:
- Primary channel icon + name
- Secondary channels
- Impact/reach indicators

## FOOTER
"Konsepti joka tekee Stark Suomista puheenaiheen ja tavoittaa uusia yleisöjä."
A compelling summary of why this concept is perfect for this brand.

## COLOR PALETTE
- Primary brand color: #f44336
- Secondary color: #f58220
- Accent color: #06326b
- Background: Rich dark base with premium lighting effects and depth, or striking bold color statement
- Text: High contrast for excellent readability

## TECHNICAL REQUIREMENTS
- 16:9 landscape layout (target 3840x2160)
- Wide, cinematic composition with clear horizontal flow
- All Finnish text must be clearly readable and well-spaced
- Professional marketing document quality matching top creative agencies
- Avoid generic stock photo aesthetics
- No AI-looking artifacts or distortions in faces
- Clean, sharp typography throughout
- Premium infographic design language
- The one-pager should immediately communicate value and create desire to learn more

```
