# Lisähuomiot (käyttäjän antama)

Huomio liikuntatrendit 2026, jonka Elixia toteuttanut yhdesä Verian/Sifo