# Lisähuomiot (käyttäjän antama)

Kuluttajille kohdistuva markkinointi. Kolme erillistä kohderyhmää 1) nuoret aikuiset 15-24v 2) aikuiset 25-45-v 3) aikuiset yli 45-v.

Eli ota huomioon myös nuoremmat kohderyhmät