# Lisähuomiot (käyttäjän antama)

Ota huomioon Nelosen Koti Koiralle -TV ohjelma osana kokonaisuutta, kehitä lisää tekemistä sen ympärille